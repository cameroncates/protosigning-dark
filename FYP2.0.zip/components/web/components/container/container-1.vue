<template>
    <div component='true' class="container p-3 my-3 border text-white">
        <h1 component='true'>A heading in a container</h1>
        <p component='true'>You can delete this above heading as well as this paragraph as well.</p>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>