<template>
    <div class="row justify-content-center m-1 p-3 connectedSortable" component='false' to-be-inserted='true' container-type='inner-container' style="min-height:100px; background:rgba(0,0,0,0.0155)">
        <!-- <div class="container row mt-1 mb-1 ml-1 mr-1 pt-2 pb-2 pl-2 pr-2" component='true' to-be-inserted='true' container-type='inner-container' ref="inner-container"> -->
            <h1 component='true' class="col-md-12">A heading in a container</h1>
            <p component='true' class="col-md-12">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem, nesciunt nihil exercitationem nam quasi recusandae accusamus nobis rem delectus explicabo voluptatibus illum eveniet consectetur quaerat distinctio obcaecati necessitatibus repudiandae optio!</p>
        <!-- </div> -->
    </div>            
</template>

<script>
export default {
}
</script>

<style>

</style>