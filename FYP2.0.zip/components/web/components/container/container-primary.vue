<template>
    <div class="container-fluid box-shadow bg-primary text-white mb-2 mt-2 p-3 connectedSortable" component='false' to-be-inserted='true' container-type='inner-container' style="min-height:100px">
        <h1 component='true' class="col-md-12">A heading in a container</h1>
        <p component='true' class="col-md-12">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem, nesciunt nihil exercitationem nam quasi recusandae accusamus nobis rem delectus explicabo voluptatibus illum eveniet consectetur quaerat distinctio obcaecati necessitatibus repudiandae optio!</p>
    </div>            
</template>

<script>
export default {
}
</script>

<style>

</style>