<template>
    <form component='true' class="p-2 box-shadow bg-white">
        <div class="input-group mb-2 p-2" component='true'>
        <div class="input-group-prepend">
            <!-- <span class="icon-delete input-group-text"></span> -->
        </div>
        <input type="email" class="form-control" placeholder="Email i.e. John-Doe@gmail.com" id="usr" name="username">
        <div class="input-group-append">
            <!-- <span class="input-group-text">@example.com</span> -->
        </div>
        </div>
    </form>

</template>

<script>
export default {

}
</script>

<style>

</style>