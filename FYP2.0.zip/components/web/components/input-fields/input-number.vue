<template>
    <form component='true' class="p-2 box-shadow">
        <div class="input-group mb-2 p-2" component='true'>
        <div class="input-group-prepend">
            <!-- <span class="icon-delete input-group-text"></span> -->
        </div>
        <input type="number" class="form-control" placeholder="1234" id="usr" name="username">
        <div class="input-group-append">
            <!-- <span class="input-group-text">@example.com</span> -->
        </div>
        </div>
    </form>

</template>

<script>
export default {

}
</script>

<style>

</style>