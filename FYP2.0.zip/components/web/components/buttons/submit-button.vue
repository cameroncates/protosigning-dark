<template>
    <button component='true' btn-type='submit' type="button" class="btn btn-primary">Submit</button>
</template>

<script>
export default {

}
</script>

<style>

</style>