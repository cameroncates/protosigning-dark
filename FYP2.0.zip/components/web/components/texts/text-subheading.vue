<template>
    <h4 component='true' class="col-md-12">Subheading Text</h4>
</template>

<script>
export default {
    methods: {
    },
    mounted() {
    }

}
</script>

<style>
</style>