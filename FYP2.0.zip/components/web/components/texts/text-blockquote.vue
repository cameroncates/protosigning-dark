<template>
    <blockquote component='true' class="blockquote p-2">
        <p component='true'>For 50 years, WWF has been protecting the future of nature. The world's leading conservation organization, WWF works in 100 countries and is supported by 1.2 million members in the United States and close to 5 million globally.</p>
        <footer component='true' class="blockquote-footer p-2">From WWF's website</footer>
    </blockquote>
</template>

<script>
export default {
    methods: {
    },
    mounted() {
    }

}
</script>

<style>
</style>