<template>
    <h1 component='true' class="p-2 display-1">Large Text</h1>
</template>

<script>
export default {
    methods: {
    },
    mounted() {
    }

}
</script>

<style>
</style>