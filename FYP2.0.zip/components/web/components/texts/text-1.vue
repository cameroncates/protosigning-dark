<template>
    <h5 component='true' class="col-md-12">This is the default text - h5.</h5>
</template>

<script>
export default {
    methods: {
    },
    mounted() {
    }

}
</script>

<style>
.text-1-component {
    display: inline-block;
    border: 1px solid rgba(0, 0, 0, 0.0525);
    padding: 5px 20px;
    margin: 5px;
    font-size: 30px;
    font-family: "Helvetica Neue", Helvetica, Arial;
    font-family: "Poppins", sans-serif;
    /* letter-spacing: 2px; */
    color: rgba(0, 0, 0, 0.525);
    font-weight: 500;
    background-color: white;
}
</style>