<template>
    <h3 component='true' class="col-md-12">Title Text</h3>
</template>

<script>
export default {
    methods: {
    },
    mounted() {
    }

}
</script>

<style>
</style>