<template>
    <p component='true' class="small col-md-12">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsum possimus, facere rem ut nostrum suscipit dolor commodi consequatur temporibus ratione? Sint quo voluptate blanditiis sit porro odio, placeat molestiae nostrum.</p>
</template>

<script>
export default {
    methods: {
    },
    mounted() {
    }

}
</script>

<style>
</style>