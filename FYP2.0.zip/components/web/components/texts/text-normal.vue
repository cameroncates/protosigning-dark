<template>
    <p component='true' class="p-2">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Molestiae corporis architecto eaque quisquam, ipsa autem numquam ipsam, nulla laborum accusamus delectus alias quam, consequuntur molestias error? Magnam, id. Sequi, corrupti! </p>
</template>

<script>
export default {
    methods: {
    },
    mounted() {
    }

}
</script>

<style>
</style>