<template>
    <img src="~/assets/images/2.jpg" class="box-shadow" alt="Cinque Terre" width="360px">   
</template>

<script>
export default {

}
</script>

<style>

</style>