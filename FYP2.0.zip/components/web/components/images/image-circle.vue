<template>
    <img src="~/assets/images/2.jpg" class="img-circle box-shadow" alt="Cinque Terre" width="360px" height="360px" style="border-radius:50%">   
</template>

<script>
export default {

}
</script>

<style>

</style>