<template>
  <img component='true' class="box-shadow" src="~/assets/images/2.jpg" alt="Cinque Terre" width="304" style="border-radius:5px">   
</template>

<script>
export default {

}
</script>

<style>

</style>