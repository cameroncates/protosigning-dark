<template>
  <div component='false' class=" d-flex justify-content-center text-center">
    <div component='true' class="pb-1 m-5 col-md-10" style="border-bottom:2px solid rgba(0,0,0,0.225)"></div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>