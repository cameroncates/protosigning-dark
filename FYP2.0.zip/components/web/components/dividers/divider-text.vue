<template>
  <div component='false' class=" d-flex justify-content-center text-center">
    <div component='true' class="p-2 m-5 col-md-10 justify-content-center flex-wrap d-flex">
        <h1 component='true' class="w-75 pb-3" style="border-bottom:1px solid rgba(0,0,0,0.225)">Splitter Heading</h1>
        <p component='true' class="col-md-7">Keep consistency in your Style Guides, UI component libraries, interactions, templates and other deliverables. Share your assets with design teams, business analysts and developers.</p>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>