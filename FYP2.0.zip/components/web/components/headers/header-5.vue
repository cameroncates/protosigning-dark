<template>
    <div style="height:460px;" :style="{background: background}" class="jumbotron d-flex justify-content-center align-content-center flex-wrap" div-type='header' component='true'>
        <h2 class="w-100 text-center header-5-h" component='true'>EXPERIENCE / INTERFACE DESIGNER</h2>
        <h5 class="w-100 text-center mt-3 header-5-h" component='true'>ROMAN LEINWATHER</h5>
        <p class="w-100 text-center mt-4 small header-5-p" component='true'>PROUD TOPTAL MEMBER - TOP 3% OF INTERNET TALENT</p>
    </div>              
  
</template>

<script>
export default {
    data() {
        return {
            background: "repeating-linear-gradient(90deg, rgba(89, 89, 89, 0.05) 0px, rgba(89, 89, 89, 0.05) 1px, transparent 1px, transparent 91px), repeating-linear-gradient(45deg, rgba(89, 89, 89, 0.05) 0px, rgba(89, 89, 89, 0.05) 1px, transparent 1px, transparent 91px), repeating-linear-gradient(0deg, rgba(89, 89, 89, 0.05) 0px, rgba(89, 89, 89, 0.05) 1px, transparent 1px, transparent 61px), repeating-linear-gradient(90deg, rgba(89, 89, 89, 0.05) 0px, rgba(89, 89, 89, 0.05) 1px, transparent 1px, transparent 61px), repeating-linear-gradient(90deg, rgba(89, 89, 89, 0.05) 0px, rgba(89, 89, 89, 0.05) 1px, transparent 1px, transparent 16px), repeating-linear-gradient(0deg, rgba(89, 89, 89, 0.05) 0px, rgba(89, 89, 89, 0.05) 1px, transparent 1px, transparent 16px), linear-gradient(90deg, rgb(21, 22, 19), rgb(21, 22, 19))"
        }
    }

}
</script>

<style>
.header-5-h {
    letter-spacing: 10px;
    font-family: 'Helvetica Neue', Helvetica, Arial;
    color:rgba(255,255,255,0.75);
}
.header-5-p {
    letter-spacing: 5px;
    color: rgba(255,255,255,0.55);
}
</style>