<template>
  <div class="border">
    <!-- <p>right</p> -->
  </div>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
    }
  },

  methods: {
  },

  mounted() {
 }

}
</script>

<style>
.nav-right-container .icon-code {
    width: 50px;
    height: 50px;
    border-radius: 50% 0px 0px 50%;
}
</style>